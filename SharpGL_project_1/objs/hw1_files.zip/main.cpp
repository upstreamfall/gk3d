#include <stdio.h>

#include "argparser.h"
#include "glCanvas.h"
#include "mesh.h"

// Included files for OpenGL Rendering
#ifdef __APPLE__
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#include <GLUT/glut.h>
#else
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#endif

// =========================================
// =========================================

int main(int argc, char *argv[]) {
  srand48(37);
  ArgParser *args = new ArgParser(argc, argv);
  Mesh *mesh = new Mesh();
  mesh->Load(args->input_file);
  GLCanvas glcanvas;

  glutInit(&argc,argv);
  glcanvas.initialize(args,mesh); 

  delete mesh;
  delete args;
  return 0;
}

// =========================================
// =========================================
