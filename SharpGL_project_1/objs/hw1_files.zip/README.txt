CSCI 4530/6530 ADVANCED COMPUTER GRAPHICS
HOMEWORK 1: SIMPLIFICATION & SUBDIVISION


NAME:


COLLABORATORS: 
You must do this assignment on your own, as described in the CS2
Academic Integrity Policy.  If you did discuss the problem or errors
messages, etc. with anyone, please list their names here.



EFFICIENCY OF MESH OPERATIONS:



NOTES ON YOUR IMPLEMENTATION:



DESCRIBE EXTENSIONS FOR EXTRA CREDIT:



MISC. COMMENTS TO GRADER:  



